# lambdas/orders/create_order.py
import json
import boto3
import uuid
from datetime import datetime
import os

dynamodb = boto3.resource('dynamodb')
orders_table = dynamodb.Table(os.environ['ORDERS_TABLE'])
order_items_table = dynamodb.Table(os.environ['ORDER_ITEMS_TABLE'])
carts_table = dynamodb.Table(os.environ['CARTS_TABLE'])
products_table = dynamodb.Table(os.environ['PRODUCTS_TABLE'])

def lambda_handler(event, context):
    try:
        # Parse request body
        body = json.loads(event['body'])
        user_id = body.get('user_id')
        shipping_address = body.get('shipping_address')
        payment_method = body.get('payment_method')
        
        # Get user's cart
        cart_response = carts_table.get_item(
            Key={'user_id': user_id}
        )
        
        if 'Item' not in cart_response:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'Cart is empty'})
            }
        
        cart = cart_response['Item']
        cart_items = cart.get('items', [])
        
        if not cart_items:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'Cart is empty'})
            }
        
        # Calculate total and verify stock
        total_amount = 0
        order_items = []

        for item in cart_items:
            product_id = item['product_id']
            quantity = item['quantity']
            
            # Get product details
            product_response = products_table.get_item(
                Key={'productId': product_id}
            )
            
            if 'Item' not in product_response:
                return {
                    'statusCode': 400,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'error': f'Product {product_id} not found'})
                }
            
            product = product_response['Item']
            
            # Check stock - handle missing stock_quantity
            stock_quantity = product.get('stock_quantity', 0)
            if stock_quantity < quantity:
                return {
                    'statusCode': 400,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'error': f'Insufficient stock for {product["name"]}'})
                }
            
            # Convert ALL Decimal values to float safely
            price = float(str(product['price'])) if 'price' in product else 0.0
            item_total = price * quantity
            total_amount += item_total
            
            order_items.append({
                'product_id': product_id,
                'name': product['name'],
                'price': price,  # Use the converted float
                'quantity': quantity,
                'item_total': item_total
            })
        
        # Create order
        order_id = str(uuid.uuid4())
        timestamp = datetime.utcnow().isoformat()
        
        order = {
            'order_id': order_id,
            'user_id': user_id,
            'status': 'pending',
            'total_amount': total_amount,
            'shipping_address': shipping_address,
            'payment_method': payment_method,
            'created_at': timestamp,
            'updated_at': timestamp
        }
        
        # Save order to DynamoDB
        orders_table.put_item(Item=order)
        
        # Save order items
        for item in order_items:
            order_items_table.put_item(Item={
                'order_id': order_id,
                'product_id': item['product_id'],
                'name': item['name'],
                'price': item['price'],
                'quantity': item['quantity'],
                'item_total': item['item_total']
            })
        
        # Clear the cart
        carts_table.update_item(
            Key={'user_id': user_id},
            UpdateExpression='SET items = :empty_list',
            ExpressionAttributeValues={
                ':empty_list': []
            }
        )
        
        return {
            'statusCode': 201,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Order created successfully',
                'order_id': order_id,
                'total_amount': total_amount,
                'status': 'pending'
            })
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }