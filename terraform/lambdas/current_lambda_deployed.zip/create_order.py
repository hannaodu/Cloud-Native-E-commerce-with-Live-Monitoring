# ../lambdas/orders/create_order_complete.py
import json
import boto3
import uuid
from datetime import datetime
import os
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
orders_table = dynamodb.Table(os.environ['ORDERS_TABLE'])
order_items_table = dynamodb.Table(os.environ['ORDER_ITEMS_TABLE'])
carts_table = dynamodb.Table(os.environ['CARTS_TABLE'])
products_table = dynamodb.Table(os.environ['PRODUCTS_TABLE'])

def lambda_handler(event, context):
    try:
        print("DEBUG: Starting COMPLETE create_order function")
        body = json.loads(event['body'])
        user_id = body.get('user_id')
        shipping_address = body.get('shipping_address', 'Test Address')
        payment_method = body.get('payment_method', 'credit_card')
        
        # Get user's cart
        cart_response = carts_table.get_item(Key={'user_id': user_id})
        if 'Item' not in cart_response:
            return error_response('Cart is empty', 400)
        
        cart = cart_response['Item']
        cart_items = cart.get('items', [])
        
        if not cart_items:
            return error_response('Cart is empty', 400)
        
        print(f"DEBUG: Processing {len(cart_items)} cart items")
        
        # Calculate total
        total_amount = 0
        order_items = []

        for item in cart_items:
            product_id = item['product_id']
            quantity = item['quantity']
            
            # Get product - USE CORRECT KEY
            product_response = products_table.get_item(Key={'productId': product_id})
            if 'Item' not in product_response:
                return error_response(f'Product {product_id} not found', 400)
            
            product = product_response['Item']
            print(f"DEBUG: Product: {product['name']}, Price: {product['price']}")
            
            # Convert price safely
            price_str = str(product['price'])
            price_float = float(price_str)
            item_total = price_float * quantity
            total_amount += item_total
            
            order_items.append({
                'product_id': product_id,
                'name': product['name'],
                'price': price_float,
                'quantity': quantity,
                'item_total': item_total
            })
        
        # Create order
        order_id = str(uuid.uuid4())
        timestamp = datetime.utcnow().isoformat()
        
        order = {
            'order_id': order_id,
            'user_id': user_id,
            'status': 'pending',
            'total_amount': Decimal(str(total_amount)),
            'shipping_address': shipping_address,
            'payment_method': payment_method,
            'created_at': timestamp,
            'updated_at': timestamp
        }
        
        # Save order
        orders_table.put_item(Item=order)
        print(f"DEBUG: Order saved: {order_id}")
        
        # Save order items
        for item in order_items:
            order_items_table.put_item(Item={
                'order_id': order_id,
                'product_id': item['product_id'],
                'name': item['name'],
                'price': Decimal(str(item['price'])),
                'quantity': item['quantity'],
                'item_total': Decimal(str(item['item_total']))
            })
        
        # Clear cart
        carts_table.update_item(
            Key={'user_id': user_id},
            UpdateExpression='SET items = :empty_list',
            ExpressionAttributeValues={':empty_list': []}
        )
        
        return {
            'statusCode': 201,
            'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'message': 'Order created successfully!',
                'order_id': order_id,
                'total_amount': total_amount,
                'status': 'pending'
            })
        }
        
    except Exception as e:
        print(f"ERROR: {str(e)}")
        return error_response(str(e), 500)

def error_response(message, code=500):
    return {
        'statusCode': code,
        'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
        'body': json.dumps({'error': message})
    }